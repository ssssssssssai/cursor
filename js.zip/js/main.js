function $(selector, root) {
  return (root || document).querySelector(selector);
}

function $all(selector, root) {
  return Array.from((root || document).querySelectorAll(selector));
}

function formatINR(amount) {
  try {
    return new Intl.NumberFormat('en-IN', { style: 'currency', currency: 'INR', maximumFractionDigits: 0 }).format(amount);
  } catch (e) {
    return `₹${amount}`;
  }
}

function setActiveNav() {
  const path = location.pathname.split('/').pop() || 'index.html';
  $all('nav .nav-links a').forEach(a => {
    const href = a.getAttribute('href');
    if (href.endsWith(path)) {
      a.classList.add('active');
    }
  });
}

document.addEventListener('DOMContentLoaded', setActiveNav);