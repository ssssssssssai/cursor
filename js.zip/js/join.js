const APPS_SCRIPT_URL = "REPLACE_WITH_YOUR_APPS_SCRIPT_WEB_APP_URL";

const UNIVERSITY = {
  NTRUHS: "NTRUHS",
  KNRUHS: "KNRUHS",
};

const NTRUHS_COLLEGES = [
  "Anil Neerukonda Institute of Dental Sciences, Visakhapatnam",
  "CKS Teja Institute of Dental Sciences and Research, Tirupati",
  "Care Dental College, Guntur",
  "Drs. Sudha & Nageswara Rao Siddhartha Institute of Dental Sciences, Gannavaram",
  "G. Pulla Reddy Dental College and Hospital, Kurnool",
  "GITAM Dental College and Hospital, Visakhapatnam",
  "GSL Dental College and Hospital, Rajahmundry",
  "KIMS Dental College, Amalapuram",
  "Lenora Institute of Dental Sciences, Rajahmundry",
  "Narayana Dental College and Hospital, Nellore",
  "Nimra Institute of Dental Sciences, Vijayawada",
  "Sibar Institute of Dental Sciences, Guntur",
  "Sree Sai Dental College and Research Institute, Srikakulam",
  "St. Joseph Dental College, Duggirala",
  "Vishnu Dental College, Bhimavaram",
  "Government Dental College & Hospital, Vijayawada",
  "Government Dental College, RIMS, Kadapa",
];

const KNRUHS_COLLEGES = [
  "Government Dental College and Hospital, Hyderabad",
  "Army College of Dental Sciences, Secunderabad",
  "Kamineni Institute of Dental Sciences, Nalgonda",
  "Mamata Institute of Dental Sciences, Khammam",
  "Meghna Institute of Dental Sciences, Nizamabad",
  "Malla Reddy Dental College for Women, Hyderabad",
  "Malla Reddy Institute of Dental Sciences, Hyderabad",
  "Panineeya Mahavidyalaya Institute of Dental Sciences & Research Centre, Hyderabad",
  "Sri Balaji Dental College, Hyderabad",
  "Sri Sai College of Dental Surgery, Vikarabad",
  "Sri Venkata Sai Institute of Dental Sciences, Hyderabad",
  "Tirumala Institute of Dental Sciences & Research Centre",
  "MNR Dental College and Hospital, Medak",
];

const YEAR_SUBJECTS = {
  "1st": [
    "Anatomy",
    "Physiology and Biochemistry",
    "Dental Anatomy",
  ],
  "2nd": [
    "Pharmacology",
    "Pathology and Microbiology",
    "Dental Materials",
  ],
  "3rd": [
    "General Medicine",
    "General Surgery",
    "Oral Pathology",
  ],
  "4th": [
    "Oral Medicine and Radiology",
    "Oral and Maxillofacial Surgery",
    "Periodontics",
    "Prosthodontics",
    "Orthodontics",
    "Conservative Dentistry and Endodontics",
    "Public Health Dentistry",
    "Pedodontics",
  ],
};

function getPricing(year, isBundle, numSubjects) {
  if (year === "4th") {
    return isBundle ? 1699 : 299 * Math.max(1, numSubjects || 1);
  }
  return isBundle ? 999 : 399 * Math.max(1, numSubjects || 1);
}

function populateColleges(selectEl, university) {
  const list = university === UNIVERSITY.NTRUHS ? NTRUHS_COLLEGES : KNRUHS_COLLEGES;
  selectEl.innerHTML = '<option value="">Select college</option>' + list.map(c => `<option value="${c}">${c}</option>`).join('');
}

function populateSubjects(container, year) {
  const subjects = YEAR_SUBJECTS[year] || [];
  container.innerHTML = subjects.map((s, idx) => {
    const id = `sub_${idx}`;
    return `<label class="inline"><input type="checkbox" name="subjects" value="${s}"> ${s}</label>`;
  }).join('');
}

function updatePriceDisplay() {
  const year = document.querySelector('select[name="year"]').value;
  const plan = document.querySelector('input[name="planType"]:checked')?.value || 'bundle';
  const isBundle = plan === 'bundle';
  const selectedSubjects = Array.from(document.querySelectorAll('input[name="subjects"]:checked')).length;
  const price = getPricing(year, isBundle, selectedSubjects);
  const priceEl = document.getElementById('price');
  if (priceEl) priceEl.textContent = formatINR(price);
}

function onUniversityChange() {
  const uni = document.querySelector('select[name="university"]').value;
  const collegeWrap = document.getElementById('college-wrap');
  const collegeSelect = document.querySelector('select[name="college"]');
  if (!uni) {
    collegeWrap.style.display = 'none';
    collegeSelect.innerHTML = '<option value="">Select college</option>';
    return;
  }
  collegeWrap.style.display = 'block';
  populateColleges(collegeSelect, uni);
}

function onYearChange() {
  const year = document.querySelector('select[name="year"]').value;
  const subjectsWrap = document.getElementById('subjects-wrap');
  populateSubjects(subjectsWrap, year);
  updatePriceDisplay();
}

function onPlanTypeChange() {
  const plan = document.querySelector('input[name="planType"]:checked')?.value || 'bundle';
  const subjectChooser = document.getElementById('subject-chooser');
  subjectChooser.style.display = plan === 'subjects' ? 'block' : 'none';
  updatePriceDisplay();
}

function getPaymentMode() {
  const mode = document.querySelector('input[name="paymentMode"]:checked');
  return mode ? mode.value : 'UPI';
}

async function submitJoinForm(e) {
  e.preventDefault();
  const submitBtn = document.getElementById('submitBtn');
  const msg = document.getElementById('formMsg');
  msg.textContent = '';

  if (!APPS_SCRIPT_URL || APPS_SCRIPT_URL.startsWith('REPLACE_')) {
    msg.className = 'notice error';
    msg.textContent = 'Setup required: Add your Apps Script URL in /workspace/site/js/join.js';
    return;
  }

  const form = e.target;
  const data = {
    type: 'enrollment',
    name: form.name.value.trim(),
    email: form.email.value.trim(),
    whatsapp: form.whatsapp.value.trim(),
    university: form.university.value,
    year: form.year.value,
    college: form.college.value || '',
    batchDate: form.batch.value,
    planType: form.planType.value,
    subjects: Array.from(document.querySelectorAll('input[name="subjects"]:checked')).map(i => i.value),
    computedPrice: document.getElementById('price').textContent,
    paymentMode: getPaymentMode(),
    paymentReference: form.reference.value.trim(),
    userAgent: navigator.userAgent,
    page: location.href,
  };

  if (data.planType === 'subjects' && data.subjects.length === 0) {
    msg.className = 'notice error';
    msg.textContent = 'Please select at least one subject or switch to Full bundle.';
    return;
  }

  try {
    submitBtn.disabled = true;
    await fetch(APPS_SCRIPT_URL, {
      method: 'POST',
      headers: { 'Content-Type': 'application/json' },
      mode: 'no-cors',
      body: JSON.stringify(data),
    });
    msg.className = 'notice success';
    msg.textContent = 'Submitted! We will confirm on WhatsApp/email shortly. If not, write to studental.queries@gmail.com.';
    form.reset();
    onUniversityChange();
    onPlanTypeChange();
    updatePriceDisplay();
  } catch (err) {
    console.error(err);
    msg.className = 'notice error';
    msg.textContent = 'Network error. Please try again or email studental.queries@gmail.com.';
  } finally {
    submitBtn.disabled = false;
  }
}

function initJoin() {
  const uniSel = document.querySelector('select[name="university"]');
  const yearSel = document.querySelector('select[name="year"]');
  const planRadios = document.querySelectorAll('input[name="planType"]');

  uniSel.addEventListener('change', onUniversityChange);
  yearSel.addEventListener('change', onYearChange);
  planRadios.forEach(r => r.addEventListener('change', onPlanTypeChange));

  document.getElementById('subjects-wrap').addEventListener('change', updatePriceDisplay);
  document.getElementById('joinForm').addEventListener('submit', submitJoinForm);

  onUniversityChange();
  onYearChange();
  onPlanTypeChange();
  updatePriceDisplay();
}

document.addEventListener('DOMContentLoaded', initJoin);