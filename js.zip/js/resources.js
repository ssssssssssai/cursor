const APPS_SCRIPT_URL_RES = "REPLACE_WITH_YOUR_APPS_SCRIPT_WEB_APP_URL";

function switchTab(id) {
  document.querySelectorAll('.tab').forEach(t => t.classList.remove('active'));
  document.querySelectorAll('.tab-panel').forEach(p => p.style.display = 'none');
  document.querySelector(`[data-tab="${id}"]`).classList.add('active');
  document.getElementById(id).style.display = 'block';
}

async function submitContact(e) {
  e.preventDefault();
  const form = e.target;
  const msg = document.getElementById('contactMsg');

  if (!APPS_SCRIPT_URL_RES || APPS_SCRIPT_URL_RES.startsWith('REPLACE_')) {
    msg.className = 'notice error';
    msg.textContent = 'Setup required: Add your Apps Script URL in /workspace/site/js/resources.js';
    return;
  }

  const payload = {
    type: 'contact',
    name: form.cname.value.trim(),
    email: form.cemail.value.trim(),
    message: form.cmessage.value.trim(),
    page: location.href,
  };

  try {
    await fetch(APPS_SCRIPT_URL_RES, {
      method: 'POST',
      headers: { 'Content-Type': 'application/json' },
      mode: 'no-cors',
      body: JSON.stringify(payload),
    });
    msg.className = 'notice success';
    msg.textContent = 'Message sent! We will reply to studental.queries@gmail.com channel.';
    form.reset();
  } catch (e2) {
    console.error(e2);
    msg.className = 'notice error';
    msg.textContent = 'Network error. Please try again later.';
  }
}

function initResources() {
  document.querySelectorAll('.tab').forEach(t => {
    t.addEventListener('click', () => switchTab(t.dataset.tab));
  });
  const contactForm = document.getElementById('contactForm');
  if (contactForm) contactForm.addEventListener('submit', submitContact);
  switchTab('papers');
}

document.addEventListener('DOMContentLoaded', initResources);